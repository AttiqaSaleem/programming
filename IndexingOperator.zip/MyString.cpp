#include"MyString.h"

MyString::MyString(const int _maxSize):currentSize(0),maxSize(_maxSize)
{
	arr = new char[maxSize];
	
}

void MyString::add(const char value)
{
	arr[currentSize] = value;
	currentSize++;
}
MyString::~MyString()
{
	if (arr)
	{
		delete[]arr;
		arr = nullptr;
	}
}
