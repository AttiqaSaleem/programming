#pragma once
#include<iostream>
using namespace std;
class MyString
{
private:
	char* arr;
	int maxSize;
	int currentSize;
public:
	MyString(const int _maxSize=100);
	void add(const char value);
	const char& operator[](const int index)const
	{
		return arr[index];
	}
	 char& operator[](const int index)
	{
		return arr[index];
	}

	~MyString();
};

