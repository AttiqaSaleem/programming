// MyString.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "MyString.h"

int main()
{
	MyString str1;
	str1.add('b');
	str1.add('a');
	str1.add('b');
	str1.add('l');
	str1.add('u');
	
	
	str1[4] = 'i';

	for (int i = 0; i < 5; i++)
	{
		cout << str1[i];
	}
	/*int arr[] = { 1,2,3,4 };
	arr[3] = 5;
	cout << arr[1];*/
     
}



